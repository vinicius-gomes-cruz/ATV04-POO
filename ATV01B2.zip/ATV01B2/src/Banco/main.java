package Banco;

public class main {

	public static void main(String[] args) {
		
		ContaCorrente contaCorrente = new ContaCorrente("CC1234","Palermo",0,5);
		
		ContaPoupanca contaPoupanca = new ContaPoupanca("CC12345","Vinicius",0,50);
		
		contaCorrente.depositar(1000);
		contaCorrente.consultarSaldo();
		contaCorrente.exibirDados();
		contaCorrente.sacar(200);
		contaCorrente.sacar(2000);
		contaCorrente.consultarSaldo();
		
		contaPoupanca.depositar(1000);
		contaPoupanca.consultarSaldo();
		contaPoupanca.exibirDados();
		contaPoupanca.aplicarRendimento();
		contaPoupanca.consultarSaldo();
		
	}

}
