package Banco;

public class ContaPoupanca extends ContaBancaria {
	double taxaRendimento;
	
	public ContaPoupanca(String numeroConta, String titular, double saldo, double taxaRendimento) {
		super(numeroConta, titular, saldo);
		this.taxaRendimento = taxaRendimento;
	}

	@Override
	public void depositar(double valor) {
		this.saldo = this.saldo + valor;
	}
	
	@Override
	public void sacar(double valor) {
		if (valor > this.saldo) {
			this.saldo = this.saldo - valor - taxaRendimento;
			System.out.println("Valor sacado");
		} else {
			System.out.println("Valor Insuficiente");

		}
	}
	
	@Override
	public void consultarSaldo() {
		System.out.println("Saldo atual: R$" + this.saldo);
	}
	
	public void exibirDados() {
		System.out.println("NumeroConta: " + this.numeroConta +
				 		   "\ntitular : " + this.titular +
				 		   "\nSaldo: " + this.saldo +
				 		   "\nTaxa de Rendimento: " + this.taxaRendimento);
	}
	
	public void aplicarRendimento() {
		this.saldo = this.saldo + this.taxaRendimento;
	}
}
