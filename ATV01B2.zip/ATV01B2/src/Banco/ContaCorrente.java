package Banco;

public class ContaCorrente extends ContaBancaria {
	double taxaManutencao;
	

	public ContaCorrente(String numeroConta, String titular, double saldo,double taxaManutencao) {
		super(numeroConta, titular, saldo);
		this.taxaManutencao = taxaManutencao;
	}

	@Override
	public void depositar(double valor) {
		this.saldo = this.saldo + valor;
	}
	
	@Override
	public void sacar(double valor) {
		if (valor < this.saldo) {
			this.saldo = this.saldo - valor - taxaManutencao;
			System.out.println("Valor sacado");
		} else {
			System.out.println("Valor Insuficiente");

		}
	}
	
	@Override
	public void consultarSaldo() {
		System.out.println("Saldo atual: R$" + this.saldo);
	}
	
	public void exibirDados() {
		System.out.println("NumeroConta: " + this.numeroConta +
				 		   "\ntitular: " + this.titular +
				 		   "\nSaldo: " + this.saldo +
				 		   "\nTaxa de Manutenção: " + this.taxaManutencao);
	}
	
}
