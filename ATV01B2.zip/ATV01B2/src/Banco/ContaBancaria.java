package Banco;

public abstract class ContaBancaria {
	String numeroConta;
	String titular;
	double saldo;
	
	public ContaBancaria(String numeroConta, String titular, double saldo) {
		super();
		this.numeroConta = numeroConta;
		this.titular = titular;
		this.saldo = saldo;
	}
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	public abstract void depositar(double valor);
	public abstract void sacar(double valor);
	public abstract void consultarSaldo();
	
	public void exibirDados() {
		System.out.println("NumeroConta:" + this.numeroConta +
				 		   "\n titular: " + this.titular +
				 		   "\n Saldo: " + this.saldo);
	}
	
}
