package main;

import java.util.List;

public class Biblioteca {
	private List<ItemBiblioteca> itens;
	private List<Usuario> usuarios;
	
	public void adicionarItem(ItemBiblioteca item) {
		
	}
	
	public void removerItem(ItemBiblioteca item) {
		
	}
	
	public void buscarPorTitulo(String titulo) {
		
	}
	
	public void registrarUsuario(Usuario usuario) {
		
	}
	
	public void listarItensDisponiveis() {
		
	}
}
