package main;

public class Revista extends ItemBiblioteca {

	private int edicao;
	private String editora;
	
	public void folhear(int pagina) {
		System.out.println("Você pasou uma página");
	}
	
	@Override
	public void getDescricao() {
		System.out.println("Edição: " + edicao);
		System.out.println("Editora: " + editora);
	}
	
}
