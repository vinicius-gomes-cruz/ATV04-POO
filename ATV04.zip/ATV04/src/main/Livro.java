package main;

public class Livro extends ItemBiblioteca {
	private int numeroPaginas;
	private String genero;
	
	public int getNumeroPaginas() {
		return numeroPaginas;
	}

	public void setNumeroPaginas(int numeroPaginas) {
		this.numeroPaginas = numeroPaginas;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}
	
	public void lerCapitulo(int capitulo) {
		System.out.println("Capitulo: " + capitulo + "Foi lido");
	}
	
	@Override
	public void getDescricao() {
		System.out.println("Titulo: " + getTitulo());
		System.out.println("Autor: " + getAutor());
		System.out.println("Ano de Publicação: " + getAnoPublicacao());
		System.out.println("Disponivel: " + isDisponivel());
		System.out.println("numeroPaginas: " + getNumeroPaginas());
		System.out.println("Genero: " + getGenero());
		
	}
	
}
