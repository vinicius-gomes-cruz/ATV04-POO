package main;

import java.util.List;

public class Usuario {
	
	private String nome;
	private int id;
	private List<ItemBiblioteca> itensEmprestados;
	
	public void emprestarItem(ItemBiblioteca item) {
		itensEmprestados.add(item);
	}
	
	public void devolverItem(ItemBiblioteca item) {
		itensEmprestados.remove(item);
	}
	
	public void listarEmprestimos() {
		for (int i = 0; i < itensEmprestados.size(); i++) {
			System.out.println(itensEmprestados.get(i));
		}
	}

}
