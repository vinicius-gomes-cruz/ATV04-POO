package main;

public class ItemBiblioteca {
	private String titulo;
	private String autor;
	private int anoPublicacao;
	private boolean disponivel = true;
	
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public int getAnoPublicacao() {
		return anoPublicacao;
	}
	public void setAnoPublicacao(int anoPublicacao) {
		this.anoPublicacao = anoPublicacao;
	}
	public boolean isDisponivel() {
		return disponivel;
	}
	public void setDisponivel(boolean disponivel) {
		this.disponivel = disponivel;
	}
	
	public void emprestar() {
		this.disponivel = false;
		System.out.println("O Livro " + titulo + " foi emprestado");
	}
	
	public void devolver() {
		this.disponivel = true;
		System.out.println("O Livro " + titulo + "foi devolvido");
	}
	
	public void getDescricao() {
		System.out.println("Titulo: " + this.titulo);
		System.out.println("Autor: " + this.autor);
		System.out.println("Ano de Publicação: " + this.anoPublicacao);
		System.out.println("Disponivel: " + this.disponivel);
	}
}
